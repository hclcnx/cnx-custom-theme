function periscope(){
    console.log("Launching Periscope Styling...");
    //Global Styling
    GM_addStyle(GM_getResourceText("global"));
    // Files Styling
    if(document.URL.includes("/files/")){
      GM_addStyle(GM_getResourceText("files"));
    }
    // Profiles Styling
    else if(document.URL.includes("/profiles/")){
      GM_addStyle("profiles");
    }
}
periscope();
