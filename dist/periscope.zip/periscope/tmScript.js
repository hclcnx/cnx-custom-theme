// ==UserScript==
// @name         Project Periscope - Connections Cloud
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Customization Demo
// @author       Mary Pelletier, Deniz Sokullu
// @require      https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js
// @require      file:///Users/deniz.sokulluibm.com/periscope/periscopeTM.js
// @resource     files file:///Users/deniz.sokulluibm.com/periscope/scss/files.css
// @resource     profiles file:///Users/deniz.sokulluibm.com/periscope/scss/profiles.css
// @resource     global file:///Users/deniz.sokulluibm.com/periscope/scss/global.css
// @match        https://apps.na.collabserv.com/files/*
// @match        https://apps.na.collabserv.com/communities/*
// @match        https://apps.na.collabserv.com/profiles/*
// @match        https://apps.na.collabserv.com/meetings/*
// @match        https://apps.na.collabserv.com/homepage/*
// @match        https://apps.na.collabserv.com/forums/*
// @match        https://apps.na.collabserv.com/wikis/*
// @grant        GM_getResourceText
// @grant        GM_addStyle
// ==/UserScript==

